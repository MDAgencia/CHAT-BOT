If you'd like to contribute to the project, please submit a Pull Request or an issue.
- All the code is written in ES5 JavaScript with compatibility expectation for IE11 browsers and later.
- No local server or developement environment is required or recommended to work on/build this project. All examples, Bubbles.js code, and CSS is expected to run straight in-browser.

Thank you!
